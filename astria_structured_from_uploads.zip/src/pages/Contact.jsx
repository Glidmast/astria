import React, { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const onChange = (e) => setForm((s) => ({ ...s, [e.target.name]: e.target.value }));
  const onSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section className="max-w-2xl">
      <h1 className="font-serif text-3xl mb-3">Contact</h1>
      <p className="text-slate-600 mb-8">
        Collector inquiries, collaborations, and artist submissions welcome.
      </p>

      <form onSubmit={onSubmit} className="space-y-4 border rounded-md p-6 bg-white">
        <div className="grid md:grid-cols-2 gap-4">
          <label className="text-sm">
            <div className="text-slate-600 mb-1">Name</div>
            <input
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-slate-200"
              name="name"
              value={form.name}
              onChange={onChange}
              required
            />
          </label>

          <label className="text-sm">
            <div className="text-slate-600 mb-1">Email</div>
            <input
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-slate-200"
              name="email"
              type="email"
              value={form.email}
              onChange={onChange}
              required
            />
          </label>
        </div>

        <label className="text-sm block">
          <div className="text-slate-600 mb-1">Message</div>
          <textarea
            className="w-full border rounded-md px-3 py-2 min-h-[140px] focus:outline-none focus:ring-2 focus:ring-slate-200"
            name="message"
            value={form.message}
            onChange={onChange}
            required
          />
        </label>

        <button className="px-5 py-3 border rounded-md text-sm bg-slate-900 text-white" type="submit">
          Send message
        </button>

        {sent && (
          <div className="text-sm text-emerald-700">
            Message captured. If you want this to actually submit (Netlify Forms/email), tell me and I’ll wire it.
          </div>
        )}
      </form>
    </section>
  );
}
